package unitTests.task02;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatrixTest {

    private void assertMatrixEquals(int[][] expected, Matrix actual) {
        assertArrayEquals(expected, actual.getData(),
                "The resulting matrix data does not match the expected array.");
    }


    @Test
    void testIsSquare() {
        int[][] squareData = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        Matrix squareMatrix = new Matrix(squareData);
        int[][] nonSquareData = {{1, 2, 3}, {4, 5, 6}};
        Matrix nonSquareMatrix = new Matrix(nonSquareData);
        assertTrue(squareMatrix.isSquare(), "A 3x3 matrix should be reported as square.");
        assertFalse(nonSquareMatrix.isSquare(), "A 2x3 matrix should be reported as non-square.");
    }


    @Test
    void testTranspose() {
        int[][] originalData = {{1, 2}, {3, 4}, {5, 6}};
        Matrix originalMatrix = new Matrix(originalData);
        int[][] expectedData = {{1, 3, 5}, {2, 4, 6}};
        Matrix transposedMatrix = originalMatrix.transpose();
        assertMatrixEquals(expectedData, transposedMatrix);
    }


    @Test
    void testAdditionDimensionMismatch() {
        Matrix matrixA = new Matrix(new int[][]{{1, 1}, {1, 1}});
        Matrix matrixB = new Matrix(new int[][]{{2, 2, 2}, {2, 2, 2}});
        Matrix matrixC = new Matrix(new int[][]{{3, 3}, {3, 3}, {3, 3}});
        assertThrows(IllegalArgumentException.class,
                () -> matrixA.add(matrixB),
                "Addition should throw an exception for matrices with different column counts.");
        assertThrows(IllegalArgumentException.class,
                () -> matrixA.add(matrixC),
                "Addition should throw an exception for matrices with different row counts.");
    }


    @Test
    void testMultiplicationDimensionMismatch() {
        Matrix matrixA = new Matrix(new int[][]{{1, 2, 3}, {4, 5, 6}});
        Matrix matrixB = new Matrix(new int[][]{{7, 8}, {9, 0}});
        assertThrows(IllegalArgumentException.class,
                () -> matrixA.multiply(matrixB),
                "Multiplication should throw an exception if the first matrix's columns don't match the second matrix's rows.");
    }


    @Test
    void testAddition() {
        Matrix matrixA = new Matrix(new int[][]{{1, 2}, {3, 4}});
        Matrix matrixB = new Matrix(new int[][]{{5, 6}, {7, 8}});
        int[][] expected = {{6, 8}, {10, 12}};
        Matrix result = matrixA.add(matrixB);
        assertMatrixEquals(expected, result);
    }

    @Test
    void testMultiplication() {
        Matrix matrixA = new Matrix(new int[][]{{1, 2, 3}, {4, 5, 6}});
        Matrix matrixB = new Matrix(new int[][]{{7, 8}, {9, 10}, {11, 12}});
        int[][] expected = {{58, 64}, {139, 154}};
        Matrix result = matrixA.multiply(matrixB);
        assertMatrixEquals(expected, result);
    }
}