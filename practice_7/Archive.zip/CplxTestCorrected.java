package unitTests.task02;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

public class CplxTestCorrected {
    private static final Cplx compareCplx = new Cplx(2, 3);
    @BeforeEach
    void setup() {
        compareCplx.re = 2;
        compareCplx.im = 3;
    }

    @Test
    void testCplxArr() {
        double[] expectedArray = {2.0, 3.0};
        double[] actualArray = compareCplx.getCplxArr();
        assertArrayEquals(expectedArray, actualArray, 0.0001);
    }

    @Test
    void testToString() {
        String expected = "2.0 + 3.0i";
        String actual = compareCplx.toString();
        assertEquals(expected, actual);
    }

    @Test
    void testAddAss() {
        Cplx c2 = new Cplx(1, 1);
        Cplx expectedResult = new Cplx(3, 4);
        Cplx actualResult = compareCplx.addAss(c2);
        assertEquals(expectedResult, actualResult,
                "addAss should modify the object to (3, 4) and return 'this'");
    }

    @Test
    void testSubAss() {
        Cplx c2 = new Cplx(1, 1);
        Cplx expectedResult = new Cplx(1, 2);
        Cplx actualResult = compareCplx.subAss(c2);
        assertEquals(expectedResult, actualResult,
                "subAss should modify the object to (1, 2) and return 'this'");
    }
}