package unitTests.task02;

import org.junit.jupiter.api.*;
import java.util.concurrent.TimeUnit;
import static org.junit.jupiter.api.Assertions.*;

public class BogoSortTest {
    private int[] testArray;
    @BeforeEach
    void setup() {
        testArray = Main.generateTestArray();
    }

    @Test
    void simpleTest() {
        Main.bogoSort(testArray);
        assertTrue(Main.isSorted(testArray),
                "bogoSort must produce a fully sorted array.");
    }

    @RepeatedTest(10)
    void repeatedSimpleTest(RepetitionInfo repetitionInfo) {

        Main.bogoSort(testArray);

        assertTrue(Main.isSorted(testArray),
                "Repetition " + repetitionInfo.getCurrentRepetition() +
                        ": bogoSort must produce a fully sorted array.");
    }
    @Test
    @Tag("performance")
    void manualPerfTest() {

        long startTime = System.currentTimeMillis();

        Main.bogoSort(testArray);

        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        System.out.println("BogoSort execution time: " + duration + " ms");
        assertTrue(Main.isSorted(testArray),
                "manualPerfTest must still verify that the array is sorted.");
    }
    @Test
    @Tag("performance")
    void autoPerfTest() {
        Main.bogoSort(testArray);

        assertTrue(Main.isSorted(testArray),
                "autoPerfTest must produce a fully sorted array and is tagged 'performance'.");
    }

    @Test
    @Timeout(value = 1, unit = TimeUnit.SECONDS)
    void finalTest() {
        Main.bogoSort(testArray);
        assertTrue(Main.isSorted(testArray),
                "finalTest must be sorted if it completes within the 1-second timeout.");
    }
}