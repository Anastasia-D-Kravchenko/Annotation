package unitTests.task02;

import java.util.Arrays;

public class Polynomial {
    private int[] coefficients;

    public Polynomial(int[] coefficients) {
        this.coefficients = Arrays.copyOf(coefficients, coefficients.length);
    }

    public int[] getCoefficients() {
        return Arrays.copyOf(this.coefficients, this.coefficients.length);
    }

    public Polynomial add(Polynomial other) {
        int maxLength = Math.max(this.coefficients.length, other.coefficients.length);
        int[] resultCoeffs = new int[maxLength];
        for (int i = 0; i < maxLength; i++) {
            int coeff1 = (i < this.coefficients.length) ? this.coefficients[i] : 0;
            int coeff2 = (i < other.coefficients.length) ? other.coefficients[i] : 0;
            resultCoeffs[i] = coeff1 + coeff2;
        }
        return new Polynomial(resultCoeffs);
    }

    public Polynomial multiply(Polynomial other) {
        int resultLength = this.coefficients.length + other.coefficients.length - 1;
        int[] resultCoeffs = new int[resultLength];
        for (int i = 0; i < this.coefficients.length; i++) {
            for (int j = 0; j < other.coefficients.length; j++) {
                int resultIndex = i + j;
                resultCoeffs[resultIndex] += this.coefficients[i] * other.coefficients[j];
            }
        }
        return new Polynomial(resultCoeffs);
    }

    public double evaluate(double x) {
        double result = 0.0;
        for (int i = this.coefficients.length - 1; i >= 0; i--) {
            result = result * x + this.coefficients[i];
        }
        return result;
    }

    public Polynomial derivative() {
        if (this.coefficients.length <= 1) {
            return new Polynomial(new int[]{0});
        }
        int resultLength = this.coefficients.length - 1;
        int[] resultCoeffs = new int[resultLength];

        for (int i = 1; i < this.coefficients.length; i++) {
            resultCoeffs[i - 1] = this.coefficients[i] * i;
        }
        return new Polynomial(resultCoeffs);
    }
}