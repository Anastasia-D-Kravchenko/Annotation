package unitTests.task02;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

public class SimpleNumericalOperationsTest {
    private SimpleNumericalOperations operations;
    @BeforeEach
    void setup() {
        operations = new SimpleNumericalOperations();
    }

    // --- Test Method 1: testAddition ---
    @Test
    void testAddition() {
        // Test case 1: Positive numbers
        int result1 = operations.add(5, 3);
        assertEquals(8, result1, "Adding two positive numbers should return the correct sum.");

        // Test case 2: Positive and negative numbers
        int result2 = operations.add(10, -4);
        assertEquals(6, result2, "Adding a positive and a negative number should return the correct difference.");

        // Test case 3: Zero and a number
        int result3 = operations.add(0, 7);
        assertEquals(7, result3, "Adding zero to a number should return the number itself.");

        // Test case 4: Negative numbers
        int result4 = operations.add(-5, -5);
        assertEquals(-10, result4, "Adding two negative numbers should return the correct negative sum.");
    }

    // --- Test Method 2: testPosNeg ---
    @Test
    void testPosNeg() {
        int positiveValue = 10;
        int negativeValue = -5;
        int zeroValue = 0;

        // Group multiple assertions using assertAll
        assertAll("Testing isPositive and isNegative methods for all cases",

                // 1. Check a POSITIVE value (e.g., 10)
                () -> assertTrue(operations.isPositive(positiveValue),
                        "Positive value (10) should be reported as isPositive=true"),
                () -> assertFalse(operations.isNegative(positiveValue),
                        "Positive value (10) should be reported as isNegative=false"),

                // 2. Check a NEGATIVE value (e.g., -5)
                () -> assertFalse(operations.isPositive(negativeValue),
                        "Negative value (-5) should be reported as isPositive=false"),
                () -> assertTrue(operations.isNegative(negativeValue),
                        "Negative value (-5) should be reported as isNegative=true"),

                // 3. Check ZERO (e.g., 0)
                () -> assertFalse(operations.isPositive(zeroValue),
                        "Zero (0) should be reported as isPositive=false"),
                () -> assertFalse(operations.isNegative(zeroValue),
                        "Zero (0) should be reported as isNegative=false")
        );
    }
}
