package unitTests.task02;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

public class CplxTest {
    private Cplx compareCplx = new Cplx(2, 3);

    // --- Test Method 1: testCplxArr ---
    @Test
    void testCplxArr() {
        double[] expectedArray = {2.0, 3.0};
        double[] actualArray = compareCplx.getCplxArr();
        assertArrayEquals(expectedArray, actualArray, 0.0001,
                "getCplxArr should return an array of {2.0, 3.0}");
    }

    // --- Test Method 2: testToString ---
    @Test
    void testToString() {
        String expected = "2.0 + 3.0i";
        String actual = compareCplx.toString();

        assertEquals(expected, actual, "toString() should format the complex number as '2.0 + 3.0i'");
    }

    // --- Test Method 3: testAddAss and testSubAss ---
    @Test
    void testAddAss() {
        Cplx c1 = new Cplx(2, 3);
        Cplx c2 = new Cplx(1, 1);
        Cplx expectedResult = new Cplx(3, 4);

        Cplx actualResult = c1.addAss(c2);

        assertEquals(expectedResult, actualResult,
                "addAss should modify the object to (3, 4) and return 'this'");
    }

    @Test
    void testSubAss() {
        Cplx c1 = new Cplx(2, 3);
        Cplx c2 = new Cplx(1, 1);
        Cplx expectedResult = new Cplx(1, 2);

        Cplx actualResult = c1.subAss(c2);

        assertEquals(expectedResult, actualResult,
                "subAss should modify the object to (1, 2) and return 'this'");
    }
}