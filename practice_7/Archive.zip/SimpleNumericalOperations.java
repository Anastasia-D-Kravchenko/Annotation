package unitTests.task02;

public class SimpleNumericalOperations {

    public int add(int a, int b) {
        // CORRECTION: Should return the sum, not the difference.
        return a + b;
    }

    public boolean isPositive(int value) {
        // CORRECTION: A positive number must be strictly greater than 0.
        return value > 0;
    }

    public boolean isNegative(int value) {
        // CORRECTION: A negative number must be strictly less than 0.
        return value < 0;
    }
}